export interface ListModel {
  id: string;
  title: string;
  content: string;
}
